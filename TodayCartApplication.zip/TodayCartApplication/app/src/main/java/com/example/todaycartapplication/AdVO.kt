package com.example.todaycartapplication

data class AdVO (
    val img3 : Int = 0,
    val name : String = "",
    val cost : String = ""
)