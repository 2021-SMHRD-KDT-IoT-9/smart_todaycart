package com.example.todaycartapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AlertDialog

class MapActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)

        //청과야채 버튼
        val btnVege : Button = findViewById(R.id.btnV_1)
        val bntVege2 : Button = findViewById(R.id.btnV_2)
        val btnVege3 : Button = findViewById(R.id.btnV_3)
        val btnVege4 : Button = findViewById(R.id.btnV_4)

        //신선상품 버튼
        val btnFresh : Button = findViewById(R.id.btnF_1)

        //계란 김치 버튼
        val btnEgg : Button = findViewById(R.id.btnF_2)

        //와인,주류,위스키 버튼
        val btnDrink : Button = findViewById(R.id.btnD_1)
        val btnDrink2 : Button = findViewById(R.id.btnD_2)

        //생활용품버튼
        val btnSang : Button = findViewById(R.id.btnS_1_1)
        val btnSang2 : Button = findViewById(R.id.btnS_1_2)
        val btnSang3 : Button = findViewById(R.id.btnS_1_3)

        //과자버튼
        val btnCook : Button = findViewById(R.id.btnC_1)
        val btnCook2 : Button = findViewById(R.id.btnC_2)
        val btnCook3 : Button = findViewById(R.id.btnC_3)
        val btnCook4 : Button = findViewById(R.id.btnC_4)
        val btnCook5 : Button = findViewById(R.id.btnC_5)

        //음료버튼
        val btnJuice : Button =  findViewById(R.id.btnJ)


    // 버튼기능

        //과자버튼기능
        btnCook.setOnClickListener {
            val items = arrayOf("콘칩","오감자","쿠크다스","꼬북칩","초코레타","아우터","통크","포카칩(오리지널)",
            "포카칩(양파맛)","포스틱","바나나킥","새우깡(오리지널)","새우깡(매운맛)","허니버터칩","꿀꽈베기",
            "뻥튀기","옛날과자묶음1","옛날과자묶음2","옛날과자묶음3")

            AlertDialog.Builder(this).apply {
                setTitle("과자1-1")
                setItems(items) { dialog, which ->
                    // 아이템 클릭 시 동작할 내용 작성
                    Log.d("MainActivity", "Selected item: ${items[which]}")
                    dialog.dismiss()
                }
                setPositiveButton("닫기", null)
                show()
            }
        }
        btnCook2.setOnClickListener {
            val items = arrayOf("콘칩","오감자","쿠크다스","꼬북칩","초코레타","아우터","통크","포카칩(오리지널)",
                "포카칩(양파맛)","포스틱","바나나킥","새우깡(오리지널)","새우깡(매운맛)","허니버터칩","꿀꽈베기",
                "뻥튀기","옛날과자묶음1","옛날과자묶음2","옛날과자묶음3")

            AlertDialog.Builder(this).apply {
                setTitle("과자1-2")
                setItems(items) { dialog, which ->
                    // 아이템 클릭 시 동작할 내용 작성
                    Log.d("MainActivity", "Selected item: ${items[which]}")
                    dialog.dismiss()
                }
                setPositiveButton("닫기", null)
                show()
            }
        }
        btnCook3.setOnClickListener {
            val items = arrayOf("콘칩","오감자","쿠크다스","꼬북칩","초코레타","아우터","통크","포카칩(오리지널)",
                "포카칩(양파맛)","포스틱","바나나킥","새우깡(오리지널)","새우깡(매운맛)","허니버터칩","꿀꽈베기",
                "뻥튀기","옛날과자묶음1","옛날과자묶음2","옛날과자묶음3")

            AlertDialog.Builder(this).apply {
                setTitle("과자1-3")
                setItems(items) { dialog, which ->
                    // 아이템 클릭 시 동작할 내용 작성
                    Log.d("MainActivity", "Selected item: ${items[which]}")
                    dialog.dismiss()
                }
                setPositiveButton("닫기", null)
                show()
            }
        }
        btnCook4.setOnClickListener {
            val items = arrayOf("콘칩","오감자","쿠크다스","꼬북칩","초코레타","아우터","통크","포카칩(오리지널)",
                "포카칩(양파맛)","포스틱","바나나킥","새우깡(오리지널)","새우깡(매운맛)","허니버터칩","꿀꽈베기",
                "뻥튀기","옛날과자묶음1","옛날과자묶음2","옛날과자묶음3")

            AlertDialog.Builder(this).apply {
                setTitle("과자1-4")
                setItems(items) { dialog, which ->
                    // 아이템 클릭 시 동작할 내용 작성
                    Log.d("MainActivity", "Selected item: ${items[which]}")
                    dialog.dismiss()
                }
                setPositiveButton("닫기", null)
                show()
            }
        }
        btnCook5.setOnClickListener {
            val items = arrayOf("콘칩","오감자","쿠크다스","꼬북칩","초코레타","아우터","통크","포카칩(오리지널)",
                "포카칩(양파맛)","포스틱","바나나킥","새우깡(오리지널)","새우깡(매운맛)","허니버터칩","꿀꽈베기",
                "뻥튀기","옛날과자묶음1","옛날과자묶음2","옛날과자묶음3")

            AlertDialog.Builder(this).apply {
                setTitle("과자1-5")
                setItems(items) { dialog, which ->
                    // 아이템 클릭 시 동작할 내용 작성
                    Log.d("MainActivity", "Selected item: ${items[which]}")
                    dialog.dismiss()
                }
                setPositiveButton("닫기", null)
                show()
            }
        }

        //생활용품버튼기능
        btnSang.setOnClickListener {
            val items = arrayOf("물티슈","일회용젓가락","일회용숟가락","가스버너","칼","도마","주걱","거름망",
            "솔","수세미","빗자루","비닐랩","종이컵","컵홀더")

            AlertDialog.Builder(this).apply {
                setTitle("생활용품1-1")
                setItems(items){
                    dialog, which -> Log.d("MainActivity", "Selected item: ${items[which]}")
                    dialog.dismiss()
                }
                setPositiveButton("닫기", null)
                show()

            }

        }
        btnSang2.setOnClickListener {
            val items = arrayOf("물티슈","일회용젓가락","일회용숟가락","가스버너","칼","도마","주걱","거름망",
                "솔","수세미","빗자루","비닐랩","종이컵","컵홀더")

            AlertDialog.Builder(this).apply {
                setTitle("생활용품1-2")
                setItems(items){
                        dialog, which -> Log.d("MainActivity", "Selected item: ${items[which]}")
                    dialog.dismiss()
                }
                setPositiveButton("닫기", null)
                show()
            }
        }
        btnSang3.setOnClickListener {
            val items = arrayOf("물티슈","일회용젓가락","일회용숟가락","가스버너","칼","도마","주걱","거름망",
                "솔","수세미","빗자루","비닐랩","종이컵","컵홀더")

            AlertDialog.Builder(this).apply {
                setTitle("생활용품1-3")
                setItems(items){
                        dialog, which -> Log.d("MainActivity", "Selected item: ${items[which]}")
                    dialog.dismiss()
                }
                setPositiveButton("닫기", null)
                show()

            }

        }

        //음료버튼기능
        btnJuice.setOnClickListener {
            val items = arrayOf("코카콜라","코카콜라제로","밀키스","밀키스제로","칠성사이다","스프라이트","아침엔사과","하늘보리",
                "환타(오렌지)","환타(파인애플)","솔의눈", "큰집식혜")

            AlertDialog.Builder(this).apply {
                setTitle("음료")
                setItems(items){
                        dialog, which -> Log.d("MainActivity", "Selected item: ${items[which]}")
                    dialog.dismiss()
                }
                setPositiveButton("닫기", null)
                show()

            }

        }

        //


    // btn.setOnClickListener {
//            val items = arrayOf("사과", "복숭아", "수박", "딸기","ddkjkdf","jkdjkagfjkajg","adjfklajflka",
//            "jdkfjakf","jdkfja","ejkejr","jdkfjkd","23rrete","hjdfkgak","fkekqw","kddkek","eiwlijak","ekwlq",
//            "dkaja","dktjq","dkqjytqiq")
//
//
//            AlertDialog.Builder(this).apply {
//                setTitle("Items Test")
//                setItems(items) { dialog, which ->
//                    // 아이템 클릭 시 동작할 내용 작성
//                    Log.d("MainActivity", "Selected item: ${items[which]}")
//                    dialog.dismiss()
//                }
//                setPositiveButton("닫기", null)
//                show()
//            }
//        }

    }
}