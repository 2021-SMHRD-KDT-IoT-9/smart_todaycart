package com.example.todaycartapplication

data class MemberVO (
    val img : Int = 0
)