package com.example.todaycart

data class Product (
    val barcode : String,
    val name : String,
    val price :Int
)