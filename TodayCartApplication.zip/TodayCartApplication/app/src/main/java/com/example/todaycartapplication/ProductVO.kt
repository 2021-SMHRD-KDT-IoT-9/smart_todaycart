package com.example.todaycartapplication

data class ProductVO (
    val img2 : Int = 0,
    val name : String = "",
    val cost : String = "",
    val location : String = "",
    val button: String = ""
        )